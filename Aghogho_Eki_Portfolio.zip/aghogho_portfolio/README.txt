Aghogho Eki Portfolio

Upload index.html and Aghogho_Eki_CV.pdf to a public static host. The portfolio is designed as a single-page professional site for finance, executive support and administrative operations roles.
